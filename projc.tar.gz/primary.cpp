/* primary.cpp */
/*
 * Implements primary router functions
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/


#include "primary.h"

Primary::Primary(int router_index, int stage, int _tun_index) : BaseRouter(router_index, stage)
{
	tun_index = _tun_index;
	//tunnel_setup();

    	//char tun_name[IFNAMSIZ];

    	///* Connect to the tunnel interface (make sure you create the tunnel interface first) */
	//std::string name = "tun" + std::to_string(tun_index);
    	//strcpy(tun_name, name.c_str());
    	//net_fd = tun_alloc(tun_name, IFF_TUN | IFF_NO_PI); 

    	//if(net_fd < 0)
    	//{
    	//    perror("Open tunnel interface");
    	//    exit(1);
    	//}
	tunnel.setup();

	std::string log1 = "primary port: " + std::to_string(get_port());
	write_log(log1);


}

Primary::~Primary()
{
	//close(net_fd);
	//tunnel_clear();
}

void Primary::tunnel_setup()
{
	std::string str = std::string("sudo ip tuntap add dev tun") + std::to_string(tun_index) + " mode tun"; 
    	const char *command = str.c_str(); 
    	system(command); 

	str = std::string("sudo ifconfig tun") + std::to_string(tun_index) + " 10.5.51.2/24 up";
	command = str.c_str(); 
    	system(command); 

	std::string rule = std::string("sudo ip rule add from ") + get_ipaddress() + std::string(" table 9 priority 8");
	std::string route1 = std::string("sudo ip route add table 9 to 18/8 dev tun") + std::to_string(tun_index);
	//std::string route2 = std::string("sudo ip route add table 9 to 128.30/16 dev tun") + std::to_string(tun_index);
	std::string route2 = std::string("sudo ip route add table 9 to 128.52/16 dev tun") + std::to_string(tun_index);
	std::string iptables = std::string("sudo iptables -A OUTPUT -p tcp --tcp-flags RST RST -j DROP");

	command = rule.c_str(); 
    	system(command); 
	command = route1.c_str(); 
    	system(command); 
	command = route2.c_str(); 
    	system(command); 
	command = iptables.c_str(); 
    	system(command); 
}

void Primary::tunnel_clear()
{
	std::string rule = std::string("sudo ip rule del from ") + get_ipaddress() + std::string(" table 9 priority 8");
	std::string route1 = std::string("sudo ip route del table 9 to 18/8 dev tun") + std::to_string(tun_index);
	//std::string route2 = std::string("sudo ip route del table 9 to 128.30/16 dev tun") + std::to_string(tun_index);
	std::string route2 = std::string("sudo ip route del table 9 to 128.52/16 dev tun") + std::to_string(tun_index);
	std::string iptables = std::string("sudo iptables -A OUTPUT -p tcp --tcp-flags RST RST -j ACCEPT");

	const char *command = iptables.c_str(); 
    	system(command); 
	command = route2.c_str(); 
    	system(command); 
	command = route1.c_str(); 
    	system(command); 
	command = rule.c_str(); 
    	system(command); 

	std::string str = std::string("sudo ifconfig tun") + std::to_string(tun_index) + " 10.5.51.2/24 down";
    	command = str.c_str(); 
    	system(command); 

	str = std::string("sudo ip tuntap del dev tun") + std::to_string(tun_index) +  " mode tun"; 
	command = str.c_str(); 
    	system(command); 
}


int Primary::tun_alloc(char *dev, int flags) 
{
    	struct ifreq ifr;
    	int fd, err;
    	char *clonedev = (char*)"/dev/net/tun";

    	if ( (fd = open(clonedev , O_RDWR)) < 0 ) 
    	{
    	    	perror("Opening /dev/net/tun");
    	    	return fd;
    	}

    	memset(&ifr, 0, sizeof(ifr));

    	ifr.ifr_flags = flags;

    	if (*dev) 
    	{
    	    	strncpy(ifr.ifr_name, dev, IFNAMSIZ);
    	}

    	if( (err = ioctl(fd, TUNSETIFF, (void *)&ifr)) < 0 ) 
    	{
    	    	perror("ioctl(TUNSETIFF)");
    	    	close(fd);
    	    	return err;
    	}

    	strcpy(dev, ifr.ifr_name);
    	return fd;
}


void Primary::run()
{
	Timers *timersManager_ = new Timers;
	Octane octane;



	char     buffer[BUFFER_LEN] = {0};
	uint16_t nread;
	struct   timeval timeout, tmv;

	int maxfd = (get_sock_fd() > tunnel.get_fd()) ? get_sock_fd():tunnel.get_fd();
/*
	Stage 9: modify /tmp/ccaptive.conf here, Jiechang Apr 22
*/
	FILE * f=fopen("/tmp/captive.conf","w");
	fprintf(f,"R0:%d\n",get_port());
/*
	End
*/
  	while(1) {

		if (ack_queue_size() > 0){
			handle expired_handle = timersManager_->NextTimerTime(&tmv);
                	if (tmv.tv_sec == 0 && tmv.tv_usec == 0) {
                	        // The timer at the head on the queue has expired 
                	        timersManager_->ExecuteNextTimer();

				uint8_t buffer[40] = {0};
				std::map<Octane*, std::tuple<BasePacket*, handle>>::iterator it;
				for ( it = ack_queue.begin(); it != ack_queue.end(); it++ ){

					if (expired_handle == std::get<1>(it->second)){
						it->first->serialize(buffer);
/*
	Stage 10:modify here for add get_next_port_stage10
*/
						uint32_t secondary_port;
						if(get_stage()==10 && it->first->get_protocol()==6)
							secondary_port=get_next_port_stage10(it->first->get_source_port());
						else 
							secondary_port = get_next_port(it->first->get_dest_ip(), it->first->get_dest_port());
/*
	End
*/
						this->send((const char*) buffer, 40, secondary_port);
					}
				}
                	        continue;
                	}
                	if (tmv.tv_sec == MAXVALUE && tmv.tv_usec == 0){
                	        // There are no timers in the event queue 
				printf("There are no timers in the event queue\n");
                	        break;
                	}
		}




  	  	int ret, port;
  	  	fd_set rd_set;

		// reset select variable
  	  	FD_ZERO(&rd_set);
  	  	FD_SET(get_sock_fd(), &rd_set); 
		FD_SET(tunnel.get_fd(), &rd_set);
		timeout.tv_sec = TIMEOUT;

  	  	ret = select(maxfd + 1, &rd_set, NULL, NULL, &timeout);
		if (ret == 0) {
			// timeout, send disconnect to all secondary routers
			std::map<uint8_t, uint32_t>::iterator it;
			for ( it = index_to_port_map.begin(); it != index_to_port_map.end(); it++ )
				disconnect(it->second);
			break;
		}

  	  	if (ret < 0 && errno == EINTR){
  	  	  	continue;
  	  	}

  	  	if (ret < 0) {
  	  	  	perror("select()");
  	  	  	exit(1);
  	  	}


  	  	if(FD_ISSET(get_sock_fd(), &rd_set)) {
			// Read from UDP socket
			this->recv(buffer, BUFFER_LEN, port);


			IP ip_hdr = IP((uint8_t *)buffer);
			switch(ip_hdr.get_protocol()){
				// Octane Message
				case 253:
				{
					Octane *octane_rcv = new Octane((uint8_t *) buffer);
/*
	Add Code for Stage 9 here.2019.Apr.22 by Jiechang Shi
	In Stage 9, primary router may receive Octane packet form Captive Portal.
*/
					if(octane_rcv->get_flag()==0)
					{
						printf("INPUT OCTANE PACKET FOR PRIME ROUTER\n");
						if(octane_rcv->get_action()==5) //Only deal AUTHENTICATED packet
						{
							prepare_rule_stage9(octane_rcv,timersManager_);
						}
					}
/*
	End
*/
					// Insert to vector after Octane ACK
					else if (ack_queue_rule(*octane_rcv) == 0){
						if (octane_rcv->get_flag() == 1){
							//BasePacket* pending_packet = ack_queue_icmp(*octane_rcv);
							//IP *ip = pending_packet->get_ip_hdr();

							// Send pending packet
							//if (pending_packet->get_protocol() != 0){
							//	uint32_t secondary_port = get_next_port(ip->get_destination_address(), octane_rcv->get_source_port());
							//	uint8_t packet[pending_packet->get_packet_length()] = {0};
							//	pending_packet->serialize(packet);
							//	this->send((const char *) packet, pending_packet->get_packet_length(), secondary_port);
							//} 
							handle timer_handle = rm_ack_queue(*octane_rcv);
							timersManager_->RemoveTimer(timer_handle);
						} else {
							printf("wrong flag\n");
							octane_rcv->print();
						}
						break;
					} else {
						printf("message not in ack queue\n");
						continue;
					}
				}


				// Connection Message
				case 254:
				{
					Message message = Message((uint8_t *) buffer);
					if (message.get_flag() == 0){
						index_to_port_map[message.get_index()] = port;

						// Log
						std::string msg = "router: " + std::to_string(message.get_index()) + ", " + 
							          "pid: "    + std::to_string(message.get_pid())                 + ", " + 
								  "port: "   + std::to_string(port);
						write_log(msg);
/*
	Stage 9: Modify /tmp/captive.conf here
*/
						if(message.get_index()==1)
						{
							fprintf(f,"R1:%d\n",port);
							fclose(f);
						}
/*
	End
*/
					}
					continue;
				}

				// ICMP
				case 1:{
					Octane* output = new Octane();
					ICMP *icmp = new ICMP((uint8_t *)buffer);
					octane = Octane();
					icmp->get_flow(octane);
					
					// Log
					std::string msg = std::string("ICMP from port: ") + std::to_string(port) + ", " +
							  "src: " + icmp->get_source_addr_str() + ", " + 
							  "dst: " + icmp->get_destination_addr_str() + ", " + 
							  "type: " + std::to_string(icmp->get_type());
					write_log(msg);

					if (find_flow(&octane, output) == 0){
						// Forward to Tunnel
						apply_rule(icmp, output, tunnel, -1);



					} else {
						// default rule
						octane.print();
						output->print();
						printf("size queue: %d\n", ack_queue_size());
					}



					break;
				       }
				 case 6:{
					Octane* output = new Octane();
					TCP *tcp = new TCP((uint8_t *)buffer);
					octane = Octane();
					tcp->get_flow(octane);

					std::string msg = tcp->get_protocol_string()              + 
						       std::string(" from port: ") + std::to_string(port)  + ", "  +
						       "("  + tcp->get_source_addr_str()      + ", " + 
					       	       std::to_string(ntohs(tcp->get_source_port())) + ", " +
						       tcp->get_destination_addr_str() + ", " +
					       	       std::to_string(ntohs(tcp->get_dest_port())) + ")";
					write_log(msg);


					if (find_flow(&octane, output) == 0){
						// Forward to Tunnel
						apply_rule(tcp, output, tunnel, -1);


					} else {
						// default rule
						octane.print();
						output->print();
						printf("size queue: %d\n", ack_queue_size());
					}
					
					
					
					}
			}
  	  	}


  	  	if(FD_ISSET(tunnel.get_fd(), &rd_set)) {
			// Read from tunnel
			if((nread = tunnel.sock_read((uint8_t*)buffer, BUFFER_LEN)) < 0){
  			  	perror("Reading data");
  			  	exit(1);
  			}

			// not IP packet
			if (buffer[0] != 0x45){
				continue;
			}


			uint8_t packet[nread];
			std::copy(buffer, buffer + nread, packet);



			IP ip = IP(packet);
			switch(ip.get_protocol()){
				case 1:{
					//ICMP
					ICMP * icmp = new ICMP(packet);
					std::string msg = icmp->get_protocol_string()              + 
						       std::string(" from tunnel, ")               +
						       "src: "  + icmp->get_source_addr_str()      + ", " + 
						       "dst: "  + icmp->get_destination_addr_str() + ", " + 
						       "type: " + std::to_string(icmp->get_type());
					write_log(msg);
					prepare_rule(icmp, timersManager_);
					break;
				}
				case 6:
					//TCP
					TCP * tcp = new TCP(packet);
					std::string msg = tcp->get_protocol_string()              + 
						       std::string(" from tunnel, (")               +
						       tcp->get_source_addr_str()      + ", " + 
						       std::to_string(ntohs(tcp->get_source_port())) + ", " +
						       tcp->get_destination_addr_str() + ", " + 
						       std::to_string(ntohs(tcp->get_dest_port())) + ")";
					write_log(msg);


				if (get_stage() == 7){
						uint16_t destination_port = ntohs(tcp->get_dest_port());
						if (destination_port == 443)
							prepare_rule_stage7(tcp, timersManager_);
						else
							prepare_rule(tcp, timersManager_);
					} else {
						prepare_rule(tcp, timersManager_);
					}

					break;
			}
  	  	}
  	}
}


void Primary::prepare_rule(BasePacket *packet, Timers *timersManager_)
{
	IP* ip = packet->get_ip_hdr();


	Octane *output = new Octane();
	Octane *octane = new Octane();
	packet->get_flow(*octane);


	if (find_flow(octane, output) < 0){
		// First Flow, set new rule
		octane->set_seqno(octane_seqno++);
		octane->set_flag(0);
		if ((ip->get_destination_address() & 0xffffff00) == 0x0a053300){
			// Set to REPLY
			octane->set_action(2);
			octane->set_port(get_port()); // primary udp socket
		} else {
			// Set to FORWARD
			octane->set_action(1);
			octane->set_port(0); // raw socket
		}

		// OUTBOUND RULE
		Timer *tcb1 = new Timer();
		handle timer_handle1 = timersManager_->AddTimer(5000, tcb1);
		add_ack_queue(*octane, packet, timer_handle1);
		uint8_t buffer1[40] = {0};
		octane->serialize(buffer1);
/* 
	stage 10:
*/
		uint32_t secondary_port;
		if(get_stage()==10 && octane->get_protocol()==6)
			secondary_port=get_next_port_stage10(octane->get_source_port());
		else
			secondary_port= get_next_port(octane->get_dest_ip(), octane->get_dest_port());
/*
	End
*/
		this->send((const char*) buffer1, 40, secondary_port);

		// INBOUND RULE
		Octane *octane_reply = new Octane();
		octane_reply->set_seqno(octane_seqno++);
		octane_reply->set_flag(0);
		packet->get_inbound_flow(*octane_reply);

		if (octane->get_action() == 1){
			Timer *tcb2 = new Timer();
			handle timer_handle2 = timersManager_->AddTimer(5000, tcb2);
			ICMP *empty = new ICMP();
			add_ack_queue(*octane_reply, empty, timer_handle2);

			uint8_t buffer2[40] = {0};
			octane_reply->set_port(get_port());
			octane_reply->set_action(1);
			octane_reply->serialize(buffer2);
			this->send((const char*) buffer2, 40, secondary_port);

		}
		// local rule
		octane->set_port(secondary_port);
		octane->set_action(1);
		add_rule(octane);

		// local rule
		octane_reply->set_port(0);
		octane_reply->set_action(1);
		add_rule(octane_reply);
		output = octane;

		if (get_stage() >= 5){
			//router: N, rule hit (SIP, SPORT, DIP, DPORT, PROTOCOL)
			std::string msg = "router: " + std::to_string(get_index()) + ", " +
					  "rule hit (" +  output->get_source_ip_str() + ", " +
					  std::to_string(ntohs(output->get_source_port())) + ", " +
					  output->get_dest_ip_str() + ", " +
					  std::to_string(ntohs(output->get_dest_port())) + ", " +
					  std::to_string(output->get_protocol()) + ")";
			write_log(msg);
		}
	} //else {
		// known rule use rule action
		apply_rule(packet, output, udpsocket, -2);
	//}

}

/*
	For Stage9, After receive Octane management packet, prepare for control packet
	Jiechang Apr.22
*/
void Primary::prepare_rule_stage9(Octane * oct_packet,Timers * timersManager_)
{
	if(get_stage()!=9) // Only work in Stage9
		return;
	Octane *octane = new Octane();
	Octane *octane_reply = new Octane();
	//For primary router control
	octane->set_action(1);
	octane->set_dest_ip(oct_packet->get_dest_ip());
	octane->set_dest_port(oct_packet->get_dest_port());
	octane->set_source_ip(oct_packet->get_source_ip());
	octane->set_source_port(oct_packet->get_source_port());
	octane->set_flag(0);
	octane->set_port(oct_packet->get_port());
	octane->set_protocol(oct_packet->get_protocol());
	add_rule(octane);

	octane->set_dest_ip(oct_packet->get_source_ip());
	octane->set_dest_port(oct_packet->get_source_port());
	octane->set_source_ip(oct_packet->get_dest_ip());
	octane->set_source_port(oct_packet->get_dest_port());
	octane->set_port(0);
	add_rule(octane);
	//For Router 1 control
	octane->set_action(1);
	octane->set_dest_ip(oct_packet->get_dest_ip());
	octane->set_dest_port(oct_packet->get_dest_port());
	octane->set_source_ip(oct_packet->get_source_ip());
	octane->set_source_port(oct_packet->get_source_port());
	octane->set_flag(0);
	octane->set_port(0);
	octane->set_seqno(octane_seqno++);
	octane->set_protocol(oct_packet->get_protocol());
	//IP *empty=new IP();
	{
		Timer *tcb1 = new Timer();
		handle timer_handle1 = timersManager_->AddTimer(2000, tcb1);
		add_ack_queue(*octane, NULL, timer_handle1);
		uint8_t buffer1[40] = {0};
		octane->serialize(buffer1);
		uint32_t secondary_port = index_to_port_map[1];
		this->send((const char*) buffer1, 40, secondary_port);
	}
	octane_reply->set_action(1);
	octane_reply->set_source_ip(oct_packet->get_dest_ip());
	octane_reply->set_source_port(oct_packet->get_dest_port());
	octane_reply->set_dest_ip(oct_packet->get_source_ip());
	octane_reply->set_dest_port(oct_packet->get_source_port());
	octane_reply->set_flag(0);
	octane_reply->set_port(get_port());
	octane_reply->set_seqno(octane_seqno++);
	octane_reply->set_protocol(oct_packet->get_protocol());
	{
		Timer *tcb1 = new Timer();
		handle timer_handle1 = timersManager_->AddTimer(2000, tcb1);
		add_ack_queue(*octane_reply, NULL, timer_handle1);
		uint8_t buffer1[40] = {0};
		octane_reply->serialize(buffer1);
		uint32_t secondary_port = index_to_port_map[1];
		this->send((const char*) buffer1, 40, secondary_port);
	}
	return;
}
/*
	End
*/

void Primary::prepare_rule_stage7(BasePacket *packet, Timers *timersManager_)
{
	Octane *output = new Octane();
	Octane *octane = new Octane();
	packet->get_flow(*octane);

	ICMP *empty = new ICMP();

	int size = index_to_port_map.size();
	
	if (find_flow(octane, output) < 0){

		for (uint8_t i = 0; i <= size; i++){

			Octane *octane_packet = new Octane();
			octane_packet->set_flag(0);
			octane_packet->set_action(1);
			packet->get_flow(*octane_packet);
			octane_packet->set_seqno(octane_seqno++);


			Octane *octane_reply = new Octane();
			octane_reply->set_flag(0);
			octane_reply->set_action(1);
			packet->get_inbound_flow(*octane_reply);
			octane_reply->set_seqno(octane_seqno++);


			if (i == 0){
				// local rule: outbound
				octane_packet->set_port(index_to_port_map[1]);
				add_rule(octane_packet);

				// local rule: inbound
				octane_reply->set_port(0);
				add_rule(octane_reply);
				continue;

			} else if (i == size) {
				octane_packet->set_port(0); 
				octane_reply->set_port(index_to_port_map[i - 1]);

			} else if (i == 1) {
				octane_packet->set_port(index_to_port_map[i + 1]); 
				octane_reply->set_port(get_port());
			} else {
				octane_packet->set_port(index_to_port_map[i + 1]); 
				octane_reply->set_port(index_to_port_map[i - 1]);
			}



			// OUTBOUND RULE
			Timer *tcb1 = new Timer();
			handle timer_handle1 = timersManager_->AddTimer(2000, tcb1); // wait 2 seconds before resend
			if (i == 1)
				add_ack_queue(*octane_packet, packet, timer_handle1);
			else
				add_ack_queue(*octane_packet, empty, timer_handle1);

			uint8_t buffer1[40] = {0};
			octane_packet->serialize(buffer1);
			this->send((const char*) buffer1, 40, index_to_port_map[i]);

			// INBOUND RULE
			if (octane_packet->get_action() == 1){
				Timer *tcb2 = new Timer();
				handle timer_handle2 = timersManager_->AddTimer(2000, tcb2);
				add_ack_queue(*octane_reply, empty, timer_handle2);

				uint8_t buffer2[40] = {0};
				octane_reply->serialize(buffer2);
				this->send((const char*) buffer2, 40, index_to_port_map[i]);

			}
		}

		output = octane;
		if (get_stage() >= 5){
			//router: N, rule hit (SIP, SPORT, DIP, DPORT, PROTOCOL)
			std::string msg = "router: " + std::to_string(get_index()) + ", " +
					  "rule hit (" +  output->get_source_ip_str() + ", " +
					  std::to_string(ntohs(output->get_source_port())) + ", " +
					  output->get_dest_ip_str() + ", " +
					  std::to_string(ntohs(output->get_dest_port())) + ", " +
					  std::to_string(output->get_protocol()) + ")";
			write_log(msg);
		}
	} //else {
		// known rule use rule action
		apply_rule(packet, output, udpsocket, -2);
	//}

}


uint32_t Primary::get_next_port(uint32_t destination_address, uint16_t destination_port){
	destination_port = ntohs(destination_port);
	if (destination_port == 80)
		if(get_stage()!=9) destination_address = 0xa05330b; // R1
		else destination_address=0xa05330d;//R3 Add here for Stage 9
	else if (destination_port == 443)
		destination_address = 0xa05330c; // R2

	// check if destination is one of the proxies' subnets
	std::map<uint8_t, uint32_t>::iterator it;

	for ( it = index_to_port_map.begin(); it != index_to_port_map.end(); it++ ) {
		uint32_t dest_ip = 0xa05330a + ((uint32_t) it->first);
		if  (destination_address == dest_ip)
			return it->second;
	}

	
	int router_index = (destination_address % index_to_port_map.size()) + 1;
	return index_to_port_map[(uint8_t) router_index];
}

/*
	Stage 10
*/
uint32_t Primary::get_next_port_stage10(uint16_t source_port){
	source_port=ntohs(source_port);
	printf("Port number=%d Router=%d\n",source_port,source_port%2==0);
	if(source_port%2==0) return index_to_port_map[2];
	else return index_to_port_map[1];
}
/*
	End
*/
