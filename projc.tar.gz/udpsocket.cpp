/* udpsocket.cpp */
/*
 * Read and write from UDP socket
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#include "udpsocket.h"

void UDPSocket::setup()
{
	int sock_fd;
	if ((sock_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		perror("Error: cannot create socket\n");
		std::exit(1);
	}

  	localAddr.sin_family      = AF_INET;
  	localAddr.sin_addr.s_addr = htonl(INADDR_ANY);
  	localAddr.sin_port        = htons(0);

  	if (bind(sock_fd, (struct sockaddr *) &localAddr, sizeof(localAddr))<0) {
  	 	printf("Error: problem binding\n");
		std::exit(1);
  	}
	set_fd(sock_fd);
}


int UDPSocket::sock_send(uint8_t* buffer, int buffer_len, uint32_t port){
	struct sockaddr_in cliaddr;
  	cliaddr.sin_family = AF_INET;
  	cliaddr.sin_addr.s_addr = htonl(INADDR_ANY);
  	cliaddr.sin_port = htons(port);

	int ret;
	if ((ret = sendto(get_fd(), (const char *)buffer, buffer_len,  
        	0, (const struct sockaddr *) &cliaddr, 
            sizeof(cliaddr))) < 0){
	
		printf("Error sending on UDP socket\n");
	} 
	return ret;
};


int UDPSocket::sock_read(uint8_t *buffer, int buffer_len){
	sockaddr_in clntAddr;
  	socklen_t addrLen = sizeof(clntAddr);
  	int datagram_length;
       	if ((datagram_length = recvfrom(get_fd(), (char *) buffer, buffer_len, 0, 
			(struct sockaddr *) &clntAddr, (socklen_t *) &addrLen)) < 0){
		printf("Error reading UDP socket\n");	
	}

  	_sourcePort = ntohs(clntAddr.sin_port);

	return datagram_length;
};


int UDPSocket::get_sourcePort(){
	return _sourcePort;
}


void UDPSocket::set_destPort(int port){
	_destPort = port;
}


int UDPSocket::get_port(){
  	unsigned int length = sizeof( localAddr );
  	if (getsockname(get_fd(), (struct sockaddr *) &localAddr, (socklen_t *) &length)<0) {
  	  	printf("Error: getsockname\n");
		std::exit(1);
  	}

  	return ntohs(localAddr.sin_port);
}
