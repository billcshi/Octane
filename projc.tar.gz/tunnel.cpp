/* tunnel.cpp */
/*
 * Read and write from tunnel
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/


#include "tunnel.h"


void Tunnel::setup()
{
	int tun_index = 1;
    	char tun_name[IFNAMSIZ];
	std::string name = "tun" + std::to_string(tun_index);
    	strcpy(tun_name, name.c_str());



	char *dev = tun_name;
	int flags = IFF_TUN | IFF_NO_PI; 
    	struct ifreq ifr;
    	int fd, err;
    	char *clonedev = (char*)"/dev/net/tun";

    	if ( (fd = open(clonedev , O_RDWR)) < 0 ) 
    	{
    	    	perror("Opening /dev/net/tun");
    	    	//return fd;
		exit(1);
    	}

    	memset(&ifr, 0, sizeof(ifr));

    	ifr.ifr_flags = flags;

    	if (*dev) 
    	{
    	    	strncpy(ifr.ifr_name, dev, IFNAMSIZ);
    	}

    	if( (err = ioctl(fd, TUNSETIFF, (void *)&ifr)) < 0 ) 
    	{
    	    	perror("ioctl(TUNSETIFF)");
    	    	close(fd);
    	    	//return err;
		exit(1);
    	}

    	strcpy(dev, ifr.ifr_name);
	set_fd(fd);
}


int Tunnel::sock_send(uint8_t* buffer, int buffer_len, uint32_t port){
	int nwrite;

	if((nwrite=write(get_fd(), buffer, buffer_len)) < 0){
		perror("Writing data");
		exit(1);
	}
	return nwrite;
};


int Tunnel::sock_read(uint8_t *buffer, int buffer_len){
	int nread = -1;
  	if((nread=read(get_fd(), buffer, buffer_len)) < 0){
  	  	perror("Reading data");
  	  	exit(1);
  	}
	return nread;
};
