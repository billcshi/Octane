/* config.cpp */
/*
 * Read and parse config files.
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#include "config.h"

bool Config::dual_spaces(char lhs, char rhs) 
{ 
	return (lhs == rhs) && (lhs == ' '); 
}

bool Config::dual_tabs(char lhs, char rhs) 
{ 
	return (lhs == rhs) && (lhs == '\t'); 
}

void Config::load(const char *filename)
{
	std::string stg("stage");
	std::string num_rout("num_routers");
	std::string drop_after("drop_after");
	std::string line;
	config_file.open(filename);
	if (config_file.is_open())
  	{
  	  	while ( getline(config_file, line) )
  	 	{
			if (line[0] == '#')
				// comment
				continue;

			
			std::string::iterator new_end = std::unique(line.begin(), line.end(), dual_spaces);
			line.erase(new_end, line.end());

			new_end = std::unique(line.begin(), line.end(), dual_tabs);
			line.erase(new_end, line.end());

			std::transform(line.begin(), line.end(), line.begin(), [](char ch) {
   				 return ch == ' ' ? '\t' : ch;
			});


			std::vector<std::string> tokens;
			std::istringstream iss(line);
    			std::string token;
    			while(std::getline(iss, token, '\t')) 
        			tokens.push_back(token);

			if (tokens.at(0) == stg)
				stage = stoi(tokens.at(1));
			else if (tokens.at(0) == num_rout)
				num_routers = stoi(tokens.at(1));
			else if (tokens.at(0) == drop_after)
				_drop_after = stoi(tokens.at(1));


  	  	}
  	  	config_file.close();
  	}
}

int Config::get_stage()
{
	return stage;

}

int Config::get_routers()
{
	return num_routers;
}

int Config::get_drop_after()
{
	return _drop_after;
}
