/* rawsocket.h */
/*
 * Read and write from raw socket
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#ifndef __RAWSOCKET_H_INCLUDED__
#define __RAWSOCKET_H_INCLUDED__

#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <fstream>
#include <algorithm>
#include <unistd.h>
#include <string.h>
#include <linux/if_tun.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/time.h>
#include <vector>
#include <map>
#include "mysocket.h"
#include "icmp.h"
#include "tcp.h"



class RawSocket : public MySocket 
{
	struct sockaddr_in raw_ip_socket;
	uint32_t ip_address;
	void set_ipaddress();
	int _index;
	std::map<std::tuple<uint16_t,uint16_t>,uint32_t> icmp_map;
	std::map<std::tuple<uint16_t,uint16_t,uint16_t,uint16_t>,uint32_t> tcp_map;
	void fix_send_header(uint8_t *);
	void fix_recv_header(uint8_t *);
	void setup(int);
	void verify_protocol(uint8_t *buffer);
	int _current_protocol = 1;
public:
	~RawSocket();
	void setup();
	int sock_send(uint8_t*, int, uint32_t);
	int sock_read(uint8_t*, int);
	void set_index(int);
	uint32_t get_ip_address();
	std::string get_source_addr_str();
};

#endif // __RAWSOCKET_H_INCLUDED__

