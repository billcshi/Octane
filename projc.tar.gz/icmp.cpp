/* icmp.cpp */
/*
 * Basic handling of ICMP packets
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#include "icmp.h"

ICMP::ICMP(uint8_t *packet)
{
	ip_hdr = IP(packet);

	std::copy(packet + 28, packet + 28 + 56, data);

	checksum   = *(uint16_t *) (packet + 22);
	identifier = *(uint16_t *) (packet + 24);
	sqn_number = *(uint16_t *) (packet + 26);

	type = (uint8_t) packet[20];
	code = (uint8_t) packet[21];

}

uint16_t ICMP::get_identifier(){
	return identifier;
}

uint16_t ICMP::get_sqn(){
	return ntohs(sqn_number);
}

std::string ICMP::get_protocol_string(){
	return std::string("ICMP");
}

// From RFC 1071
uint16_t ICMP::calculate_checksum(uint8_t *addr, short count)
{
       /* Compute Internet Checksum for "count" bytes
        *         beginning at location "addr".
        */
	register long sum = 0;

	while( count > 1 )  {
           /*  This is the inner loop */
               sum += *(uint16_t *) addr;
	       addr += 2;
               count -= 2;
       	}

           /*  Add left-over byte, if any */
       	if ( count > 0 )
               sum += * (uint8_t *) addr;

           /*  Fold 32-bit sum to 16 bits */
       	while (sum>>16)
           	sum = (sum & 0xffff) + (sum >> 16);

       	return (uint16_t) ~sum;
}


void ICMP::serialize(uint8_t *packet)
{
	ip_hdr.serialize(packet);

	packet[22] = 0; // set checksum to 0
	packet[23] = 0; // set checksum to 0

	packet[20] = type;
	packet[21] = code;

	memcpy(packet + 24, &identifier, sizeof(uint16_t));
	memcpy(packet + 26, &sqn_number, sizeof(uint16_t));

	std::copy(data, data + 56, packet + 28);

	uint16_t chksum = calculate_checksum(packet + 20, 64);
	packet[22] = chksum & 0xff;
        packet[23] = (chksum >> 8) & 0xff;

}


int ICMP::get_type()
{
	return type;
}


void ICMP::set_type(int _type){
	type = _type;
}


uint32_t ICMP::get_source_addr()
{
	return ip_hdr.get_source_address();
}


uint32_t ICMP::get_destination_addr()
{
	return ip_hdr.get_destination_address();
}


void ICMP::reply(uint8_t *packet)
{
	uint32_t new_source = ip_hdr.get_destination_address();
	uint32_t new_destination = ip_hdr.get_source_address();

	type = 0;
	forward(packet, new_source, new_destination);
}


void ICMP::forward(uint8_t *packet, uint32_t source, uint32_t destination)
{
	ip_hdr.set_destination_address(destination);
	ip_hdr.set_source_address(source);

	serialize(packet);
}


uint16_t ICMP::get_ip_length(){
	return ip_hdr.get_packet_length();
}


uint8_t ICMP::get_protocol(){
	return ip_hdr.get_protocol();
}


void ICMP::set_reply(){
	uint32_t new_source = ip_hdr.get_destination_address();
	uint32_t new_destination = ip_hdr.get_source_address();
	set_type(0);
	ip_hdr.set_destination_address(new_destination);
	ip_hdr.set_source_address(new_source);
}


void ICMP::get_flow(Octane& flow){
	flow.set_source_ip(ip_hdr.get_source_address());
	flow.set_dest_ip(ip_hdr.get_destination_address());
	flow.set_protocol(ip_hdr.get_protocol());
}

void ICMP::get_inbound_flow(Octane& flow){
	flow.set_source_ip(ip_hdr.get_destination_address());
	flow.set_dest_ip(ip_hdr.get_source_address());
	flow.set_protocol(ip_hdr.get_protocol());
}
