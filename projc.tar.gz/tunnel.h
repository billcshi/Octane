/* tunnel.h */
/*
 * Read and write from tunnel
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#ifndef __TUNNEL_H_INCLUDED__
#define __TUNNEL_H_INCLUDED__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/if_tun.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <bits/stdc++.h>
#include <map>
#include "mysocket.h"



class Tunnel : public MySocket 
{
public:
	void setup();
	int sock_send(uint8_t*, int, uint32_t);
	int sock_read(uint8_t*, int);
};

#endif // __TUNNEL_H_INCLUDED__
