a) Reused Code:
	* Downloading and Using the projb_current code from TA's website
	* Modifying the primary.cpp:
		* adding code to generate control packet to primary router and secondary router after receive the AUTHENTICATED packet.
		* The changing part is marked by comment in primary.cpp
b) Complete:
	* The HTTP traffic will direct to Router 3 when projc began
	* After receive the AUTHENTICATED packet, the HTTP traffic will redirect to Router 1
	* I think the Stage9 is completed
c) Security/privacy:
	* If you use HTTPS, the parameter of GET and even the method you used("GET") is encrypted in the packet, so it cannot be known during network transmit.
	* However, after the packet arrive the server, packet will decrypt, since using GET method, the GET parameter is part of URL, so the plaintext of username and password will record in the log of webserver.
	* To replace it, using POST rather than GET can avoid the plaintext of passward exposed in plaintext in server log.
d) Security/authentication:
	* In stage 9, the source_ip_addr is recorded in AUTHENTICATED packet, so the system identify users by ip_address.
e) Insecurity/authentication:
	* The ip_address is almost a bad way to track user, everyone can spoofy their IP_address by simply modify their IP_header.
	* Also with NAT, one IP_address may have multiple users.

