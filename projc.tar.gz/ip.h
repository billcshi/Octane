/* ip.h */
/*
 * Basic handling of IP packets
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#ifndef __IP_H_INCLUDED__
#define __IP_H_INCLUDED__


#include <algorithm>
#include <cstdio>
#include <arpa/inet.h>
#include <cstring>

class IP
{
    	uint8_t  ip_v:4, ip_hl:4; /* this means that each member is 4 bits */
	uint8_t  tos;
	uint16_t tot_len;
	uint16_t id;
	uint16_t frag_off;
	uint8_t  ttl;
	uint8_t  protocol;
	uint16_t check;
	uint32_t saddr;
	uint32_t daddr;
	void     calculate_checksum();
public:
	IP();
	IP(unsigned char *);
	~IP();
	void operator = (const IP &);
	uint16_t get_id();
	void serialize(unsigned char []);
	void set_source_address(uint32_t addr);
	uint32_t get_source_address();
	void set_destination_address(uint32_t addr);
	uint32_t get_destination_address();
	unsigned short calculate_checksum(unsigned char *, short);
	uint16_t get_packet_length();
	void set_protocol(uint8_t);
	uint8_t get_protocol();
	uint8_t get_header_length();
};
#endif // __IP_H_INCLUDED__

