/* ip.h */
/*
 * Basic handling of IP packets
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#include "ip.h"


IP::IP(){}



IP::IP(unsigned char *packet)
{
	ip_v     = (*(uint8_t *) packet) >> 4;
	ip_hl    = (*(uint8_t *) packet) & 0xf;
	tos      = *(uint8_t *) (packet + 1);
	tot_len  = ntohs(*(uint16_t *) (packet + 2));
	id       = ntohs(*(uint16_t *) (packet + 4));
	frag_off = ntohs(*(uint16_t *) (packet + 6));
	ttl      = *(uint8_t *) (packet + 8);
	protocol = *(uint8_t *) (packet + 9);
	check    = ntohs(*(uint16_t *) (packet + 10));
	saddr    = ntohl(*(uint32_t *) (packet + 12));
	daddr    = ntohl(*(uint32_t *) (packet + 16));
}


IP::~IP()
{
}

void IP::operator = (const IP &I ) {
	ip_v     = I.ip_v    ; 
	ip_hl    = I.ip_hl   ; 
	tos      = I.tos     ; 
	tot_len  = I.tot_len ; 
	id       = I.id      ; 
	frag_off = I.frag_off; 
	ttl      = I.ttl     ; 
	protocol = I.protocol; 
	check    = I.check   ; 
	saddr    = I.saddr   ; 
	daddr    = I.daddr   ; 
}

void IP::serialize(unsigned char packet[])
{
	packet[11] = 0; // clear prior checksum
	packet[10] = 0; // clear prior checksum

	packet[0]  = ip_v << 4 | (ip_hl & 0xf);
	packet[1]  = tos;
	packet[3]  = tot_len & 0xff;
	packet[2]  = (tot_len >> 8) & 0xff;
	packet[5]  = id & 0xff;
	packet[4]  = (id >> 8) & 0xff;
	packet[7]  = frag_off & 0xff;
	packet[6]  = (frag_off >> 8) & 0xff;
	packet[8]  = ttl;
	packet[9]  = protocol;
	packet[15] = saddr & 0xff;
	packet[14] = (saddr >> 8) & 0xff;
	packet[13] = (saddr >> 16) & 0xff;
	packet[12] = (saddr >> 24) & 0xff;
	packet[19] = daddr & 0xff;
	packet[18] = (daddr >> 8) & 0xff;
	packet[17] = (daddr >> 16) & 0xff;
	packet[16] = (daddr >> 24) & 0xff;

	unsigned short checksum = calculate_checksum(packet, 20);
	packet[11] = checksum & 0xff;
	packet[10] = (checksum >> 8) & 0xff;
}

uint16_t IP::get_id(){
	return id;
}

void IP::set_source_address(uint32_t addr)
{
	saddr = addr;
}


uint32_t IP::get_source_address()
{
	return saddr;
}


void IP::set_destination_address(uint32_t addr)
{
	daddr = addr;
}


uint32_t IP::get_destination_address()
{
	return daddr;
}


unsigned short IP::calculate_checksum(unsigned char *addr, short count)
{
       /* Compute Internet Checksum for "count" bytes
        *         beginning at location "addr".
        */
       register long sum = 0;

       while( count > 1 )  {
           /*  This is the inner loop */
               sum += *addr << 8 | *(addr + 1);
	       addr += 2;
               count -= 2;
       }

           /*  Add left-over byte, if any */
       if( count > 0 )
               sum += * (unsigned char *) addr;

           /*  Fold 32-bit sum to 16 bits */
       while (sum>>16)
           sum = (sum & 0xffff) + (sum >> 16);

       return (unsigned short) ~sum;
}


uint16_t IP::get_packet_length(){
	return tot_len;
}


uint8_t IP::get_protocol(){
	return protocol;
}

void IP::set_protocol(uint8_t proto){
	protocol = proto;
}

uint8_t IP::get_header_length(){
	return ip_hl * 4; // (4 bytes)
}
