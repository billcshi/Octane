/* baserouter.h */
/*
 * Base class that can be used as a template for constructing routers
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/



#ifndef __BASEROUTER_H_INCLUDED__
#define __BASEROUTER_H_INCLUDED__

#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <fstream>
#include <algorithm>
#include <unistd.h>
#include <string.h>
#include <linux/if_tun.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/time.h>
#include <vector>
#include <deque>
#include <map>
#include "message.h"
#include "octane.h"
#include "icmp.h"
#include "timers/timers.hh"
#include "udpsocket.h"

#define BUFFER_LEN 16000 //2048
#define TIMEOUT 15

class BaseRouter
{
	std::ofstream log;
	int index;
	int stage;
	int _drop_after = 0x7fffffff;
	bool _drop_one = true;
	std::string ip_address;
	std::deque<Octane> flow_rules;
	void set_stage(int);
	void set_ipaddress();
public:
	UDPSocket udpsocket;
	BaseRouter(int, int);
	~BaseRouter();
	std::map<Octane*, std::tuple<BasePacket*, handle>> ack_queue;
	int get_port();
	int get_stage();
	int get_index();
	void send(const char *, int, int);
	int recv(char *, int, int&);
	void write_log(const std::string);
	int get_sock_fd();
	void connect(int);
	void disconnect(int);
	std::string get_ipaddress();
	virtual void run() = 0;
	int find_flow(Octane*, Octane*);
	//void delete_all_http_rule();
	void add_rule(Octane*);
	void add_ack_queue(Octane&, BasePacket*, handle);
	handle rm_ack_queue(Octane&);
	int ack_queue_size();
	BasePacket* ack_queue_icmp(Octane&); 
	handle ack_queue_handle(Octane&);
	int ack_queue_rule(Octane&);
	void apply_rule(BasePacket*, Octane*, MySocket&, int);
	void set_drop_after(int);
};


#endif // __BASEROUTER_H_INCLUDED__
