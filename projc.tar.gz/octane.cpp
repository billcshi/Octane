/* octane.cpp */
/*
 * Class that deals with octane message format
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#include "octane.h"

Octane::Octane(){
	ip_hdr.set_protocol(253);
}

Octane::Octane(uint8_t *packet) : Octane()
{
	ip_hdr      = IP(packet);
	action      = *(uint8_t *)  (packet + 20);
	flag        = *(uint8_t *)  (packet + 21);
	seqno       = *(uint16_t *) (packet + 22);
	source_ip   = *(uint32_t *) (packet + 24);
	dest_ip     = *(uint32_t *) (packet + 28);
	source_port = *(uint16_t *) (packet + 32);
	dest_port   = *(uint16_t *) (packet + 34);
	protocol    = *(uint16_t *) (packet + 36);
	port        = *(uint16_t *) (packet + 38);
};

Octane::Octane(uint32_t src_ip, uint32_t dst_ip, uint16_t src_port, uint16_t dst_port, uint16_t proto) : Octane()
{
	ip_hdr.set_protocol(253);
	source_ip = src_ip;
	dst_ip    = dst_ip;
	src_port  = src_port;
	dst_port  = dst_port;
	protocol  = proto;
}


Octane::Octane(Octane* octane)
{
	ip_hdr      = octane->ip_hdr       ; 
	action      = octane->action       ; 
	flag        = octane->flag         ; 
	seqno       = octane->seqno        ; 
	source_ip   = octane->source_ip    ; 
	dest_ip     = octane->dest_ip      ; 
	source_port = octane->source_port  ; 
	dest_port   = octane->dest_port    ; 
	protocol    = octane->protocol     ; 
	port        = octane->port         ; 
}


void Octane::operator = (const Octane &O ) 
{
	ip_hdr      = O.ip_hdr      ;
	action      = O.action      ;
	flag        = O.flag        ;
	seqno       = O.seqno       ;
	source_ip   = O.source_ip   ;
	dest_ip     = O.dest_ip     ;
	source_port = O.source_port ;
	dest_port   = O.dest_port   ;
	protocol    = O.protocol    ;
	port        = O.port        ;
}

void Octane::set_action(uint8_t _action){
	action = _action;
}

uint8_t Octane::get_action(){
	return action;
}


void Octane::set_flag(uint8_t _flag){
	flag = _flag;
}

uint8_t Octane::get_flag(){
	return flag;
}


void Octane::set_seqno(uint16_t seq){
	seqno = seq;
}

uint16_t Octane::get_seqno(){
	return seqno;
}

void Octane::set_source_ip(uint32_t src_ip){
	source_ip = src_ip;
}

uint32_t Octane::get_source_ip(){
	return source_ip;
}

std::string Octane::get_source_ip_str()
{
    struct in_addr ip_addr;
    ip_addr.s_addr = htonl(get_source_ip());
    return inet_ntoa(ip_addr);
}

void Octane::set_dest_ip(uint32_t dst_ip){
	dest_ip = dst_ip;
}

uint32_t Octane::get_dest_ip(){
	return dest_ip;
}

std::string Octane::get_dest_ip_str()
{
    struct in_addr ip_addr;
    ip_addr.s_addr = htonl(get_dest_ip());
    return inet_ntoa(ip_addr);
}

void Octane::set_dest_port(uint16_t dst_port){
	dest_port = dst_port;
}

uint16_t Octane::get_source_port(){
	return source_port;
}

void Octane::set_source_port(uint16_t src_port){
	source_port = src_port;
}

uint16_t Octane::get_dest_port(){
	return dest_port;
}

void Octane::set_protocol(uint16_t proto){
	protocol = proto;
}

uint16_t Octane::get_protocol(){
	return protocol;
}

void Octane::set_port(uint16_t _port){
	port = _port;
}

uint16_t Octane::get_port(){
	return port;
}

std::tuple<uint32_t, uint32_t, uint16_t, uint16_t, uint16_t> Octane::get_tuple()
{
	return std::make_tuple(source_ip, dest_ip, source_port, dest_port, protocol);
}


void Octane::serialize(uint8_t* buffer)
{
	ip_hdr.serialize(buffer);

	memcpy(buffer + 20, &action,      sizeof(uint8_t));
	memcpy(buffer + 21, &flag,        sizeof(uint8_t));
	memcpy(buffer + 22, &seqno,       sizeof(uint16_t));
	memcpy(buffer + 24, &source_ip,   sizeof(uint32_t));
	memcpy(buffer + 28, &dest_ip,     sizeof(uint32_t));
	memcpy(buffer + 32, &source_port, sizeof(uint16_t));
	memcpy(buffer + 34, &dest_port,   sizeof(uint16_t));
	memcpy(buffer + 36, &protocol,    sizeof(uint16_t));
	memcpy(buffer + 38, &port,        sizeof(uint16_t));
}


void Octane::print(){
	printf("%02X\t%02X\t%d\t%d\t%d\t%d\n", source_ip, dest_ip, source_port, dest_port, protocol, seqno );

}
