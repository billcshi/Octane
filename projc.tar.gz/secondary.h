/* secondary.h */
/*
 * Implements Secondary's specific functions
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#ifndef __SECONDARY_H_INCLUDED__
#define __SECONDARY_H_INCLUDED__


#include <map>
#include <tuple>
#include "baserouter.h"
#include "icmp.h"
#include "tcp.h"
#include "ip.h"
#include "rawsocket.h"


class Secondary : public BaseRouter
{
	int raw_fd;
	uint32_t ip_address;
	uint32_t internal_ip;
	RawSocket rawsocket;
public:
	Secondary(int, int);
	~Secondary();
	void run();
	void forward(ICMP *msg);
	void prepare_rule(BasePacket *);
};

#endif // __SECONDARY_H_INCLUDED__

