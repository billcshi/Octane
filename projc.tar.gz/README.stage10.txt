a) Reused Code
	* Using Code(projb_current) downloading from TA website
	* In stage10, add function in primary.cpp
	* The code modification is marked with comment line.
b) Complete:
	* Stage 10 is completed
	* The TCP packet from odd port will direct to Router 1 and even port will direct to Router 2
c) Load balancing by packet or by flow:
	* A good thing to use packet-by-packet is using packet-level control is fine-granularity.
	* Since the network traffic is heavy-tail according to papers mention in class. Some flows, likes streaming video, will use most of the network traffic and other flows, likes file, will use little traffic. So control in flows-level will result in traffic unbalance between two routers.
d) Load balancing by packet or by flow, part II:
	* One problematic of use packet-by-packet:
	* We assume the two routers have equal output bandwidth at the project but this is not always true in real-world.
	* We assume the bandwidth for router1 is 1Mb/s and router2 is 1Gb/s
	* Using a packet-by-packet balance system, we assume using TCP to watch a streaming video. Since TCP need to provide ordering packet. The packet from router2 need to wait the packet from router 1 finish. So the total bandwidth is only 2Mb/s, about 500 times less than its original bandwidth.
