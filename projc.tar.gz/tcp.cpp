/* tcp.cpp */
/*
 * Basic handling of TCP packets
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#include "tcp.h"


TCP::TCP(uint8_t *packet){

	ip_hdr = IP(packet);
	uint8_t ip_hdr_size = ip_hdr.get_header_length();

	_source_port = *(uint16_t *) (packet + ip_hdr_size); 
	_dest_port   = *(uint16_t *) (packet + ip_hdr_size + 2);
	_seq_num     = *(uint32_t *) (packet + ip_hdr_size + 4);
	_ack_num     = *(uint32_t *) (packet + ip_hdr_size + 8);
	_flags       = *(uint16_t *) (packet + ip_hdr_size + 12);
	_wsize       = *(uint16_t *) (packet + ip_hdr_size + 14);
	_chksum      = *(uint16_t *) (packet + ip_hdr_size + 16);
	_urg_pointer = *(uint16_t *) (packet + ip_hdr_size + 18);
	_payload = new uint8_t[get_packet_length() - ip_hdr_size - 20];
	std::copy(packet + ip_hdr_size + 20, packet + get_packet_length(), _payload);
}



void TCP::serialize(uint8_t *packet){
	// CALCULATE CHECKSUM
	uint8_t  ip_hdr_size = ip_hdr.get_header_length();
	uint16_t tcp_size    = get_packet_length() - ip_hdr_size;
	_chksum = 0; // reset checksum


	// prepare pseudo-ip-header
	uint32_t source_ip  = ntohl(ip_hdr.get_source_address());
	uint32_t dest_ip    = ntohl(ip_hdr.get_destination_address());
	uint8_t  protocol   = ip_hdr.get_protocol();
	uint16_t length     = htons(tcp_size);


	// temp buffer
	uint8_t buffer[12 + tcp_size] = {0};
	memcpy(buffer,      &source_ip, sizeof(uint32_t));
	memcpy(buffer + 4,  &dest_ip,   sizeof(uint32_t));
	memcpy(buffer + 9,  &protocol,  sizeof(uint8_t));
	memcpy(buffer + 10, &length,    sizeof(uint16_t));


	memcpy(buffer + 12, &_source_port, sizeof(uint16_t));
	memcpy(buffer + 14, &_dest_port  , sizeof(uint16_t));
	memcpy(buffer + 16, &_seq_num    , sizeof(uint32_t));
	memcpy(buffer + 20, &_ack_num    , sizeof(uint32_t));
	memcpy(buffer + 24, &_flags      , sizeof(uint16_t));
	memcpy(buffer + 26, &_wsize      , sizeof(uint16_t));
	memcpy(buffer + 28, &_chksum     , sizeof(uint16_t));
	memcpy(buffer + 30, &_urg_pointer, sizeof(uint16_t));
	std::copy(_payload, _payload + get_packet_length() - ip_hdr_size - 20, buffer + 32);

	_chksum = calculate_checksum(buffer, tcp_size + 12);


	// RETURN SERIALIZED PACKET
	ip_hdr.serialize(packet);
	std::copy(buffer + 12, buffer + 12 + tcp_size, packet + ip_hdr_size);
	memcpy(packet + ip_hdr_size + 16, &_chksum, sizeof(uint16_t));
}


std::string TCP::get_protocol_string(){
	return std::string("TCP");
}


void TCP::set_reply(){

}


uint16_t TCP::get_source_port(){
	return _source_port;
}


uint16_t TCP::get_dest_port(){
	return _dest_port;
}

void TCP::get_flow(Octane& flow){
	flow.set_source_ip(ip_hdr.get_source_address());
	flow.set_dest_ip(ip_hdr.get_destination_address());
	flow.set_protocol(ip_hdr.get_protocol());
	flow.set_source_port(_source_port);
	flow.set_dest_port(_dest_port);
}

void TCP::get_inbound_flow(Octane& flow){
	flow.set_source_ip(ip_hdr.get_destination_address());
	flow.set_dest_ip(ip_hdr.get_source_address());
	flow.set_protocol(ip_hdr.get_protocol());
	flow.set_source_port(_dest_port);
	flow.set_dest_port(_source_port);
}


uint16_t TCP::calculate_checksum(uint8_t *addr, short count)
{
	register long sum = 0;

	while( count > 1 )  {
               sum += *(uint16_t *) addr;
	       addr += 2;
               count -= 2;
       	}

       	if ( count > 0 )
               sum += * (uint8_t *) addr;

       	while (sum>>16)
           	sum = (sum & 0xffff) + (sum >> 16);

       	return (uint16_t) ~sum;
}
