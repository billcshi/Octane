/* secondary.cpp */
/*
 * Implements Secondary's specific functions
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/



#include "secondary.h"

Secondary::Secondary(int index, int stage) : BaseRouter(index, stage) {
	pid_t pid = getpid();
	std::string msg = "router: " + std::to_string(index) +  ", pid: " + std::to_string(pid) + ", port: " + std::to_string(get_port());
	write_log(msg);


	// Bring NIC up
	//std::string str = std::string("sudo ifconfig eth") + std::to_string(index) + " 192.168.20" + std::to_string(index) + ".2/24 up"; 
    	//const char *command = str.c_str(); 
	//printf("%s\n", command);
    	//system(command); 

	rawsocket.set_index(index);
	rawsocket.setup();
	

	ip_address = (192 << 24) | (168 << 16) | ((200 + index) << 8) | 2;
	internal_ip = (10 << 24) | (5 << 16) | 51 << 8 | (2 + index);



	if (get_stage() >= 5){
		// Set default rule: DROP
		Octane *octane = new Octane();
		octane->set_action(3);
		add_rule(octane);
	}
}

Secondary::~Secondary()
{

}


void Secondary::run()
{
	int port;
	char buffer[BUFFER_LEN] = {0};
	uint16_t nread;
  	int maxfd;

	maxfd = (get_sock_fd() > rawsocket.get_fd()) ? get_sock_fd():rawsocket.get_fd();

  	while(1) {
  	  	int ret;
  	  	fd_set rd_set;

  	  	FD_ZERO(&rd_set);
  	  	FD_SET(get_sock_fd(), &rd_set); 
		FD_SET(rawsocket.get_fd(), &rd_set);

  	  	ret = select(maxfd + 1, &rd_set, NULL, NULL, NULL);
  	  	if (ret < 0 && errno == EINTR){
  	  	  	continue;
  	  	}

  	  	if (ret < 0) {
  	  	  	perror("select()");
  	  	  	exit(1);
  	  	}


  	  	if(FD_ISSET(get_sock_fd(), &rd_set)) {

			// Read socket
			this->recv(buffer, BUFFER_LEN, port);

			IP ip_hdr = IP((uint8_t *)buffer);
			switch(ip_hdr.get_protocol()){
				// Octane Message
				case 253:
				{
					Octane* octane = new Octane((uint8_t *) buffer);
					if (octane->get_flag() == 0){

						add_rule(octane);

						uint8_t packet[40] = {0};
						octane->set_flag(1);
						octane->serialize(packet);
						this->send((const char *) packet, 40, port);
					}

					continue;
				}


				// Disconnection Message
				case 254:	
				{
					Message message = Message((uint8_t *)buffer);
					if (message.get_flag() == 1){
						break;
					}
					continue;
				}

				// ICMP
				case 1:{
					ICMP *icmp = new ICMP((uint8_t*)buffer);

					// Log
					std::string msg = std::string("ICMP from port: ") + std::to_string(port) + ", " + 
						          "src: " + icmp->get_source_addr_str() + ", " + 
							  "dst: " + icmp->get_destination_addr_str() + ", " + 
							  "type: " + std::to_string(icmp->get_type());
					write_log(msg);

					prepare_rule(icmp);
					continue;
				}

				// TCP
				case 6:{
					TCP *tcp = new TCP((uint8_t*)buffer);

					std::string msg = tcp->get_protocol_string()              + 
						       std::string(" from port: ") + std::to_string(port)  + ", "  +
						       "("  + tcp->get_source_addr_str()      + ", " + 
					       	       std::to_string(ntohs(tcp->get_source_port())) + ", " +
						       tcp->get_destination_addr_str() + ", " +
					       	       std::to_string(ntohs(tcp->get_dest_port())) + ")";
					write_log(msg);

					prepare_rule(tcp);
					continue;
				}


			}
			break;
  	  	}

  	  	if(FD_ISSET(rawsocket.get_fd(), &rd_set)) {
			// Read from tunnel
  			if((nread=rawsocket.sock_read((uint8_t*)buffer, BUFFER_LEN)) < 0){
  			  	perror("Reading data");
  			  	exit(1);
  			}
			
			// not IP packet
			if (buffer[0] != 0x45){
				continue;
			}


			IP* ip = new IP((uint8_t*)buffer);
			switch(ip->get_protocol()){
				case 1:{
					// ICMP
					ICMP *icmp = new ICMP((uint8_t*)buffer);

					// Log
					std::string msg = std::string("ICMP from raw sock, ") + 
						          "src: "  + icmp->get_source_addr_str() + ", " + 
							  "dst: "  + icmp->get_destination_addr_str() + ", " + 
							  "type: " + std::to_string(icmp->get_type());
					write_log(msg);
					prepare_rule(icmp);
					break;
				}
				case 6:{
					//TCP
					TCP * tcp = new TCP((uint8_t*)buffer);

					std::string msg = tcp->get_protocol_string()              + 
						       std::string(" from raw sock, (")               +
						       tcp->get_source_addr_str()      + ", " + 
						       std::to_string(ntohs(tcp->get_source_port())) + ", " +
						       rawsocket.get_source_addr_str() + ", " + 
						       std::to_string(ntohs(tcp->get_dest_port())) + ")";
					write_log(msg);

					prepare_rule(tcp);
					break;
				}
			}
  	  	}
  	}
}


void Secondary::prepare_rule(BasePacket *packet)
{
	Octane *octane = new Octane();
	Octane *output = new Octane();
	packet->get_flow(*octane);
	if (find_flow(octane, output) == 0){
		if (output->get_port() == 0){
			// Outgoing traffic to the Internet
			apply_rule(packet, output, rawsocket, -4);
		} else 
			apply_rule(packet, output, udpsocket, 0);

	} else {
		printf("Secondary rule not found\n");
	}
}

void Secondary::forward(ICMP *msg){
	uint32_t pckt_dest = msg->get_destination_addr();
	int plength = 84;
	uint8_t packet[plength] = {0};
	msg->serialize(packet);
	rawsocket.sock_send(packet + 20, 64, pckt_dest);
}
