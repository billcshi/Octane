/* baserouter.cpp */
/*
 * Base class that can be used as a template for constructing routers
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#include "baserouter.h"

BaseRouter::BaseRouter(int _index, int _stage) : index(_index)
{
	set_stage(_stage);
	set_ipaddress();
	udpsocket.setup();
}

BaseRouter::~BaseRouter()
{
	int _true = 1;
	setsockopt(udpsocket.get_fd(),SOL_SOCKET,SO_REUSEADDR,&_true,sizeof(int));


	std::string msg = "router " + std::to_string(index) + " closed";
	write_log(msg);

  	log.close();
}


void BaseRouter::set_stage(int proj_stage)
{
	stage = proj_stage;
	if (log.is_open())
		log.close();
	log.open("stage" + std::to_string(stage) + ".r" + std::to_string(index) + ".out");

}


int BaseRouter::get_stage(){
	return stage;
}


int BaseRouter::get_port()
{
	return udpsocket.get_port();
}


void BaseRouter::send(const char * msg, int length, int port)
{
	udpsocket.sock_send((uint8_t*)msg, length, port);
}


int BaseRouter::recv(char *buffer, int bufferLen, int &sourcePort)
{
	int datagram_length = udpsocket.sock_read((uint8_t*)buffer, bufferLen);
	sourcePort = udpsocket.get_sourcePort();

	return datagram_length;

}


void BaseRouter::write_log(const std::string msg)
{
	if (log.is_open())
	{
		log << msg << "\n";
		log.flush();
	}

}

int BaseRouter::get_sock_fd()
{
	return udpsocket.get_fd();
}


void BaseRouter::connect(int server_port){
	Message message;
	message.set_flag(0);
	message.set_pid(getpid());
	message.set_index(index);
	uint8_t buffer[26]= {0};
	message.serialize(buffer);
	this->send((const char*)buffer, 26, server_port);
}


void BaseRouter::disconnect(int client_port){
	if (!client_port)
		return;

	Message message;
	message.set_flag(1);
	message.set_index(index);
	uint8_t buffer[26]= {0};
	message.serialize(buffer);
	this->send((const char*) buffer, 26, client_port);
}


void BaseRouter::set_ipaddress()
{
	char   psBuffer[128];
   	FILE   *pPipe;

	std::string ls = std::string("ifconfig eth") + std::to_string(index) + " | sed -En 's/127.0.0.1//;s/.*inet (addr:)?(([0-9]*\\.){3}[0-9]*).*/\\2/p'";
   	if( (pPipe = popen( ls.c_str(), "r" )) == NULL ) {
   	   	exit( 1 );
	}

   	while(fgets(psBuffer, 128, pPipe))
		ip_address = std::string(psBuffer);

	ip_address.erase(std::remove(ip_address.begin(), ip_address.end(), '\n'), ip_address.end());
}


std::string BaseRouter::get_ipaddress()
{
	return ip_address;
}

int BaseRouter::find_flow(Octane* received, Octane* output)
{
	for(std::deque<Octane>::iterator it = flow_rules.begin(); it != flow_rules.end(); ++it) {

		bool source_ip   = (it->get_source_ip()   == 0xffffffff) || (received->get_source_ip()   == it->get_source_ip());
		bool dest_ip     = (it->get_dest_ip()     == 0xffffffff) || (received->get_dest_ip()     == it->get_dest_ip());
		bool source_port = (it->get_source_port() == 0xffff)     || (received->get_source_port() == it->get_source_port());
		bool dest_port   = (it->get_dest_port()   == 0xffff)     || (received->get_dest_port()   == it->get_dest_port());
		bool protocol    = (it->get_protocol()    == 0xffff)     || (received->get_protocol()    == it->get_protocol());

		if (source_ip && dest_ip && source_port && dest_port && protocol){
			output->set_action(it->get_action());
			output->set_flag(it->get_flag());
			output->set_seqno(it->get_seqno());
			output->set_source_ip(it->get_source_ip());
			output->set_dest_ip(it->get_dest_ip());
			output->set_source_port(it->get_source_port());
			output->set_dest_port(it->get_dest_port());
			output->set_protocol(it->get_protocol());
			output->set_port(it->get_port());

			if (stage >= 5){
				//router: N, rule hit (SIP, SPORT, DIP, DPORT, PROTOCOL)
				std::string msg = "router: " + std::to_string(index) + ", " +
						  "rule hit (" +  output->get_source_ip_str() + ", " +
						  std::to_string(ntohs(output->get_source_port())) + ", " +
						  output->get_dest_ip_str() + ", " +
						  std::to_string(ntohs(output->get_dest_port())) + ", " +
						  std::to_string(output->get_protocol()) + ")";
				write_log(msg);
			}
			return 0;
		}
	}

	// Flow not found
	return -1;

}


void BaseRouter::add_rule(Octane *new_rule)
{
	if ((int)flow_rules.size() > _drop_after && _drop_one){
		// DROP ONE
		new_rule->set_action((uint8_t) 3);
		_drop_one = false;
	} 
	
	flow_rules.push_front(*new_rule);

	if (stage >= 4){
		//router: N, rule installed (SIP, SPORT, DIP, DPORT, PROTOCOL) action ACTION
		std::string msg = "router: " + std::to_string(index) + ", " +
				  "rule installed (" +  new_rule->get_source_ip_str() + ", " +
				  std::to_string(ntohs(new_rule->get_source_port())) + ", " +
				  new_rule->get_dest_ip_str() + ", " +
				  std::to_string(ntohs(new_rule->get_dest_port())) + ", " +
				  std::to_string(new_rule->get_protocol()) + ") action " + std::to_string(new_rule->get_action());
		write_log(msg);
	}
}


void BaseRouter::add_ack_queue(Octane& rule, BasePacket* pending_packet, handle _handle)
{
	ack_queue[&rule] = std::make_tuple(pending_packet, _handle);
}


handle BaseRouter::rm_ack_queue(Octane& rule)
{
	std::map<Octane*, std::tuple<BasePacket*, handle>>::iterator it;
	for ( it = ack_queue.begin(); it != ack_queue.end(); it++ )
	{
		if (it->first->get_tuple() == rule.get_tuple() && it->first->get_seqno() == rule.get_seqno())
		{
			handle timer_handle = std::get<1>(it->second);
			ack_queue.erase(it->first);
			return timer_handle;
		}
	}
	return 0;
}


int BaseRouter::ack_queue_rule(Octane &rule){
	std::map<Octane*, std::tuple<BasePacket*, handle>>::iterator it;
	for ( it = ack_queue.begin(); it != ack_queue.end(); it++ )
	{
		if (it->first->get_tuple() == rule.get_tuple() && it->first->get_seqno() == rule.get_seqno())
			return 0;
	}
	return -1;
}


int BaseRouter::ack_queue_size(){
	return ack_queue.size();
}



BasePacket* BaseRouter::ack_queue_icmp(Octane& rule){
	std::map<Octane*, std::tuple<BasePacket*, handle>>::iterator it;
	for ( it = ack_queue.begin(); it != ack_queue.end(); it++ )
	{
		if (it->first->get_tuple() == rule.get_tuple() && it->first->get_seqno() == rule.get_seqno())
			return std::get<0>(ack_queue[it->first]);
	}
	return new ICMP();
}


handle BaseRouter::ack_queue_handle(Octane& rule){
	std::map<Octane*, std::tuple<BasePacket*, handle>>::iterator it;
	for ( it = ack_queue.begin(); it != ack_queue.end(); it++ )
	{
		if (it->first->get_tuple() == rule.get_tuple() && it->first->get_seqno() == rule.get_seqno())
			return std::get<1>(ack_queue[it->first]);
	}
	return -1;
}


void BaseRouter::apply_rule(BasePacket* packet, Octane* rule, MySocket& mysocket, int port)
{
	IP *ip = packet->get_ip_hdr();
	switch(rule->get_action()){
		// FORWARD
		case 1:{
			uint8_t msg[packet->get_packet_length()];
			packet->serialize(msg);

			uint32_t _port;
			if (rule->get_port() == 0)
				_port = ip->get_destination_address();
			else
				_port = rule->get_port();

			mysocket.sock_send((uint8_t*)msg, packet->get_packet_length(), _port);
			break;
		}

		// REPLY
		case 2:{
			packet->set_reply();

			uint8_t msg[84];
			packet->serialize(msg);
			mysocket.sock_send((uint8_t*)msg, 84, rule->get_port());
			break;
		}

		// DROP
		case 3:
		       // do nothing
			break;

		// REMOVE
		case 4:
			break;
	}
}


void BaseRouter::set_drop_after(int drop_after){
	_drop_after = drop_after;
}


int BaseRouter::get_index(){
	return index;
}
