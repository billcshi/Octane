a) Reused Code
	* Downloading and unzip the projb_current.tar.gz from TA website
		* My project B code is not work well
	* Make no modify in code for Stage 8(No need in stage 8)
	* Modify Makefile to output projc
b) Complete:
	* Since Stage 8 make no change in code as Stage 6, Stage 8 is complete
	* The additional thing to doin Stage 8 is installing Proxy Application squid
c) Diversion of HTTP and HTTPS:
	* For HTTPS: Web browser will check the server's certification from packet's SSL layer and will block any page violate the certification check.
d) Diversion of HTTP and HTTPS, take 2:
	* Firstly I will disable the certification check of the web browser, or add a fake license to web brower
	* Then I will split the TCP connection on Proxy


