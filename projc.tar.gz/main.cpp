/* main.cpp */
/*
 * Application start point.
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#include <sys/wait.h>
#include "config.h"
#include "primary.h"
#include "secondary.h"


int main(int argc, char **argv)
{
	// Read config file
	Config config;
	config.load(argv[1]);

	int router_index = 0;
	int tun_index    = 1;
	Primary primary(router_index, config.get_stage(), tun_index);


	int n = config.get_routers();

	for (int i = 0; i < n; i++)
	{
		pid_t pid = fork();
	   	if(pid < 0) // Couldn't create process
	   	{
	   	   	// Error handling code...
	   	}
	   	else if(pid == 0) // Child process
	   	{
			Secondary secondary(i+1, config.get_stage());
			secondary.set_drop_after(config.get_drop_after());
			secondary.connect(primary.get_port());
			secondary.run();
			secondary.~Secondary();
			exit(1);
	   	}
	   	else if (i + 1 == n)// Parent process
	   	{
			primary.run();
			primary.~Primary();

	   	}
	}

	exit(0);
}
