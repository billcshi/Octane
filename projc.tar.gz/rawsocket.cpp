/* rawsocket.cpp */
/*
 * Read and write from raw socket
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#include "rawsocket.h"

RawSocket::~RawSocket()
{
	close(get_fd());

}


void RawSocket::setup()
{
	set_ipaddress();
	setup(IPPROTO_ICMP);
}

void RawSocket::setup(int protocol){
	int raw_fd = socket(AF_INET, SOCK_RAW, protocol);
	if (raw_fd < 0){
		exit(1);
	}


  	raw_ip_socket.sin_family = AF_INET;
  	raw_ip_socket.sin_addr.s_addr = htonl(ip_address);
  	//raw_ip_socket.sin_port = htons(0);

  	if (bind(raw_fd, (struct sockaddr *) &raw_ip_socket, sizeof(raw_ip_socket))<0) {
  	 	printf("Error: problem binding\n");
		std::exit(1);
  	}
	set_fd(raw_fd);
}


int RawSocket::sock_send(uint8_t* buffer, int buffer_len, uint32_t dest_address){
	verify_protocol(buffer);
	fix_send_header(buffer);

	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(dest_address);

	struct iovec iov[1];
	iov[0].iov_base = buffer + 20;
	iov[0].iov_len  = buffer_len - 20;
	
	struct msghdr message;
	message.msg_name=&addr;
	message.msg_namelen=sizeof(addr);
	message.msg_iov=iov;
	message.msg_iovlen=1;
	message.msg_control=0;
	message.msg_controllen=0;

	if (sendmsg(get_fd(), &message,0)==-1) {
	    printf("error\n");
	}
	return 0;
};


int RawSocket::sock_read(uint8_t *buffer, int buffer_len){

	int nread;
	if((nread=read(get_fd(), buffer, buffer_len)) < 0){
	  	perror("Reading data");
	  	exit(1);
	}

	fix_recv_header(buffer);
	return nread;
};


void RawSocket::set_ipaddress()
{
	char   psBuffer[128];
   	FILE   *pPipe;

	std::string ls = std::string("ifconfig eth") + std::to_string(_index) + " | sed -En 's/127.0.0.1//;s/.*inet (addr:)?(([0-9]*\\.){3}[0-9]*).*/\\2/p'";
   	if( (pPipe = popen( ls.c_str(), "r" )) == NULL ) {
   	   	exit( 1 );
	}

	std::string ip;
   	while(fgets(psBuffer, 128, pPipe))
		ip = std::string(psBuffer);

	ip.erase(std::remove(ip.begin(), ip.end(), '\n'), ip.end());


	//std::string s = ip_address;
	std::string delimiter = ".";
	uint8_t number = 0;

	uint32_t address = 0;
	size_t pos = 0;
	int index = 0;
	std::string token;
	std::string::size_type sz;
	while ((pos = ip.find(delimiter)) != std::string::npos) {
	    	token = ip.substr(0, pos);
		number = (uint8_t) std::stoi(token, &sz);	
		address = address | number << (24 - 8*index);
		index++;
	    	ip.erase(0, pos + delimiter.length());
	}
	token = ip.substr(0, pos);
	number = (uint8_t) std::stoi(token, &sz);	
	address = address | number;

	ip_address = address;
}


void RawSocket::set_index(int index){
	_index = index;
}


uint32_t RawSocket::get_ip_address(){
	return ip_address;
}

std::string RawSocket::get_source_addr_str()
{
    struct in_addr ip_addr;
    //ip_addr.s_addr = htonl(ip_hdr.get_source_address());
    ip_addr.s_addr = htonl(ip_address);
    return inet_ntoa(ip_addr);
}


void RawSocket::verify_protocol(uint8_t *buffer){
	IP *ip = new IP(buffer);
	if (_current_protocol != ip->get_protocol())
	{
		int new_protocol;
		switch(ip->get_protocol()){
			case 1:{
				new_protocol = IPPROTO_ICMP;
				break;
			       }
			case 6:{
			       new_protocol = IPPROTO_TCP;
			       break;
			       }
		}	
		sock_close();
		_current_protocol = ip->get_protocol();
		setup(new_protocol);
	}

}


void RawSocket::fix_send_header(uint8_t *buffer){
	IP *ip = new IP(buffer);
	switch(ip->get_protocol()){
		case 1:{
		       	ICMP* icmp = new ICMP(buffer); 
			ip = icmp->get_ip_hdr();
			std::tuple<uint16_t,uint16_t> key = std::make_tuple(icmp->get_sqn(), 
									icmp->get_identifier());
			icmp_map[key] = ip->get_source_address();
			ip->set_source_address(get_ip_address());
			icmp->serialize(buffer);
		       	break;
		       }
		case 6:{
		       	TCP* tcp = new TCP(buffer); 
			ip = tcp->get_ip_hdr();
			std::tuple<uint16_t,uint16_t,uint16_t,uint16_t> key = std::make_tuple(
									get_ip_address(),
									ip->get_destination_address(),
									tcp->get_source_port(), 
									tcp->get_dest_port());
			tcp_map[key] = ip->get_source_address();
			ip->set_source_address(get_ip_address());
			tcp->serialize(buffer);
		       }
	
	
	}

}

void RawSocket::fix_recv_header(uint8_t *buffer){
	IP *ip = new IP(buffer);
	switch(ip->get_protocol()){
		case 1:{
		       	ICMP* icmp = new ICMP(buffer); 
			ip = icmp->get_ip_hdr();
			std::tuple<uint16_t,uint16_t> key = std::make_tuple(icmp->get_sqn(), icmp->get_identifier());
			uint32_t destination = icmp_map[key];

			icmp_map.erase(key);
			ip->set_destination_address(destination);
			icmp->serialize(buffer);
		       	break;
		       }
		case 6:{
		       	TCP* tcp = new TCP(buffer); 
			ip = tcp->get_ip_hdr();
			std::tuple<uint16_t,uint16_t,uint16_t,uint16_t> key = std::make_tuple(
									ip->get_destination_address(),
									ip->get_source_address(),
									tcp->get_dest_port(), 
									tcp->get_source_port());
			uint32_t destination = tcp_map[key];
			ip->set_destination_address(destination);
			tcp->serialize(buffer);
		       }
	}

}
