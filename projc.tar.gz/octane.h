/* octane.cpp */
/*
 * Class that deals with octane message format
 */

/*
* This code "USC CSci551 SP2019 Project" is
* Copyright (C) 2019 by Guillermo Baltra.
* All rights reserved.
*
* This program is released ONLY for the purposes of Spring 2019 CSci551
* students who wish to use it as part of their project assignments.
* Use for another other purpose requires prior written approval by
* Guillermo Baltra.
*
* Use in CSci551 is permitted only provided that ALL copyright notices
* are maintained and that this code is distinguished from new
* (student-added) code as much as possible.  We new services to be
* placed in separate (new) files as much as possible.  If you add
* significant code to existing files, identify your new code with
* comments.
*
* As per class assignments, use of any code OTHER than this provided
* code requires explicit approval, ahead of time, by the professor.
*
*/

#ifndef __OCTANE_H_INCLUDED__
#define __OCTANE_H_INCLUDED__

#include <tuple>
#include <cstring>
#include "ip.h"


class Octane 
{
	IP       ip_hdr;
	uint8_t  action;
	uint8_t  flag;
	uint16_t seqno;
	uint32_t source_ip   = 0xffffffff;
	uint32_t dest_ip     = 0xffffffff;
	uint16_t source_port = 0xffff;
	uint16_t dest_port   = 0xffff;
	uint16_t protocol    = 0xffff;
	uint16_t port;

public:
	Octane();
	Octane(uint8_t *packet);
	Octane(uint32_t src_ip, uint32_t dst_ip, uint16_t src_port, uint16_t dst_port, uint16_t proto);
	Octane(Octane*);
	void operator = (const Octane &);
	void     set_action(uint8_t);
	uint8_t  get_action();
	void     set_flag(uint8_t);
	uint8_t  get_flag();
	void     set_seqno(uint16_t seq);
	uint16_t get_seqno();
	void     set_source_ip(uint32_t);
	uint32_t get_source_ip();
	std::string get_source_ip_str();
	void     set_dest_ip(uint32_t);
	uint32_t get_dest_ip();
	std::string get_dest_ip_str();
	void     set_source_port(uint16_t);
	uint16_t get_source_port();
	void     set_dest_port(uint16_t);
	uint16_t get_dest_port();
	void     set_protocol(uint16_t);
	uint16_t get_protocol();
	void     set_port(uint16_t);
	uint16_t get_port();
	std::tuple<uint32_t, uint32_t, uint16_t, uint16_t, uint16_t> get_tuple();
	void serialize(uint8_t*);
	void print();
};

#endif // __OCTANE_H_INCLUDED__
